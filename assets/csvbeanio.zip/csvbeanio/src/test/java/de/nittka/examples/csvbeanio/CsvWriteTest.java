package de.nittka.examples.csvbeanio;

import java.io.StringWriter;

import org.beanio.BeanWriter;
import org.junit.Assert;
import org.junit.Test;

public class CsvWriteTest {

	@Test
	public void writeCsv(){
		CsvLineFormat format=new CsvLineFormat("stringColumn","numberColumn","newColumn1","newColumn2");
		StringWriter writer=new StringWriter();
		BeanWriter beanWriter=format.getBeanWriterWithHeaderLineWritten(writer);
		writeCsvLine("s1", 1, "col3_1", "col4_1", beanWriter);
		writeCsvLine("s2", 2, null, "col4_2", beanWriter);
		beanWriter.close();

		checkWrittenCsv(writer.toString());
	}

	private void writeCsvLine(String string, int number, String col3, String col4, BeanWriter writer){
		CsvLine line = new CsvLine();
		line.setStringColumn(string);
		line.setNumberColumn(number);
		line.addGenericCsvEntry(new GenericCsvEntries("newColumn1", col3));
		line.addGenericCsvEntry(new GenericCsvEntries("newColumn2", col4));
		writer.write(line);
	}

	private void checkWrittenCsv(String csv){
		String[] lines = csv.split("\r\n");
		Assert.assertEquals(3,lines.length);
		Assert.assertEquals("stringColumn,numberColumn,newColumn1,newColumn2", lines[0]);
		Assert.assertEquals("s1,1,col3_1,col4_1", lines[1]);
		Assert.assertEquals("s2,2,,col4_2", lines[2]);
	}
}
