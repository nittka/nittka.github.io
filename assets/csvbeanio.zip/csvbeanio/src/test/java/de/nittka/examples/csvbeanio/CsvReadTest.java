package de.nittka.examples.csvbeanio;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.beanio.BeanReader;
import org.junit.Assert;
import org.junit.Test;

import com.google.common.io.Files;

public class CsvReadTest {

	@Test
	public void readFile() throws IOException {
		File file = new File("src/test/resources/test.csv");
		BeanReader beanReader = createReader(file);
		Object line;
		while ((line = beanReader.read()) != null) {
			if (line instanceof CsvLine) {
				processCsvLine((CsvLine) line, beanReader.getLineNumber());
			}
		}
		beanReader.close();
	}

	private BeanReader createReader(File file) throws IOException{
		String columnHeaderLine = Files.asCharSource(file, StandardCharsets.UTF_8).readFirstLine();
		//if necessary, you could even (try to) determine the separator from the first line
		//and make the format configurable
		CsvLineFormat format = new CsvLineFormat(columnHeaderLine.split(",", -1));
		BeanReader beanReader = format.getBeanReader(new FileReader(file));
		return beanReader;
	}

	private static void processCsvLine(CsvLine line, int lineNumber) {
		System.out.println(String.format("line %d: %s", lineNumber, line));
		if(lineNumber==2){
			Assert.assertEquals("x", line.getStringColumn());
			Assert.assertEquals(2, line.getNumberColumn().intValue());
			Assert.assertEquals("foo", line.getGenericCsvEntries().get("strangeColumn"));
			Assert.assertEquals("bar", line.getGenericCsvEntries().get("newColumn"));
		}else{
			Assert.fail("expected no further line..."+line);
		}
	}
}
