package de.nittka.examples.csvbeanio;

import java.util.Objects;

import org.beanio.types.TypeConversionException;
import org.beanio.types.TypeHandler;

/**
 * Type handler for serializing and deserializing generic csv entries
 * 
 * Each column gets its own handler which knows the column it is responsible for.
 * 
 * When deserializing, the handler creates a generic entry with a single key-value-pair
 * which is then merged into the generic entry of the entire line.
 * 
 * When serializing, the handler extracts the value of the column it is responsible for
 * from the generic entry.
 * */
class GenericCsvEntriesHandler implements TypeHandler {

	private String csvColumnName;

	public GenericCsvEntriesHandler(String csvColumnName) {
		this.csvColumnName=Objects.requireNonNull(csvColumnName);
	}
	
	public Object parse(String text) throws TypeConversionException {
		return new GenericCsvEntries(csvColumnName, text);
	}

	public String format(Object value) {
		if(value==null){
			return null;
		}else if(value instanceof GenericCsvEntries){
			return ((GenericCsvEntries) value).get(csvColumnName);
		}else{
			throw new IllegalArgumentException("unexpected type "+value.getClass());
		}
	}

	public Class<?> getType() {
		return GenericCsvEntries.class;
	}
}
