package de.nittka.examples.csvbeanio;

import java.io.Reader;
import java.io.Writer;
import java.util.List;
import java.util.Objects;

import org.beanio.BeanReader;
import org.beanio.BeanWriter;
import org.beanio.StreamFactory;
import org.beanio.builder.CsvParserBuilder;
import org.beanio.builder.FieldBuilder;
import org.beanio.builder.RecordBuilder;
import org.beanio.builder.StreamBuilder;

import com.google.common.collect.ImmutableList;

public class CsvLineFormat {

	private static final String CSV_FILE = "csvFile";
	private static final String CSV_HEADER_LINE = "headerLine";
	private static final String CSV_DATA_LINE = "dataLine";
	//typed (non-generic) fields of CsvLine
	private static final List<String> KNOWN_TYPED_COLUMNS = ImmutableList.of("stringColumn", "numberColumn");

	private String[] columns;

	public CsvLineFormat(String... columns) {
		this.columns = Objects.requireNonNull(columns);
	}

	public BeanReader getBeanReader(Reader reader) {
		return getStreamFactory().createReader(CSV_FILE, reader);
	}

	public BeanWriter getBeanWriterWithHeaderLineWritten(Writer writer) {
		BeanWriter beanWriter = getStreamFactory().createWriter(CSV_FILE, writer);
		beanWriter.write(CSV_HEADER_LINE, null);
		return beanWriter;
	}

	private StreamFactory getStreamFactory() {
		StreamFactory factory = StreamFactory.newInstance();
		StreamBuilder builder = new StreamBuilder(CSV_FILE, "csv")
				.parser(getParserBuilder())
				.addRecord(getHeaderBuilder())
				.addRecord(getLineBuilder());
		factory.define(builder);
		return factory;
	}

	private CsvParserBuilder getParserBuilder() {
		CsvParserBuilder parserBuilder = new CsvParserBuilder();
		//here you can set delimiters, quoting information etc.
		return parserBuilder;
	}

	//the header line is mandatory and contains the column names
	private RecordBuilder getHeaderBuilder() {
		RecordBuilder headerBuilder = new RecordBuilder(CSV_HEADER_LINE)
			.order(1)
			.minOccurs(1)
			.maxOccurs(1);
		for (String column : columns) {
			headerBuilder.addField(new FieldBuilder(column).defaultValue(column));
		}
		return headerBuilder;
	}

	private RecordBuilder getLineBuilder() {
		RecordBuilder csvLineBuilder = new RecordBuilder(CSV_DATA_LINE, CsvLine.class)
			.order(2)
			.occurs(0, -1);
		for (String header : columns) {
			FieldBuilder fieldBuilder = new FieldBuilder(header);
			if (!KNOWN_TYPED_COLUMNS.contains(header)) {
				//each unknown column gets its own type handler
				//along with the information how the data is accessed in the CsvLine-Object
				fieldBuilder.typeHandler(new GenericCsvEntriesHandler(header))
					.getter("getGenericCsvEntries")
					.setter("addGenericCsvEntry");
			}else{
				//known fields can have type handlers as well
				//e.g. if you want to need some conversion
			}
			csvLineBuilder.addField(fieldBuilder);
		}
		return csvLineBuilder;
	}
}