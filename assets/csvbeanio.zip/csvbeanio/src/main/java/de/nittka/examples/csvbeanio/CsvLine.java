package de.nittka.examples.csvbeanio;

import com.google.common.base.MoreObjects;

/**
 * data structure representing a line of the csv file
 * */
public class CsvLine {

	//typed, known data fields
	private String stringColumn;
	private Integer numberColumn;
	//storage for "unknown" data fields
	private GenericCsvEntries genericCsvEntries;

	public void setStringColumn(String stringColumn) {
		this.stringColumn = stringColumn;
	}

	public String getStringColumn() {
		return stringColumn;
	}

	public void setNumberColumn(Integer numberColumn) {
		this.numberColumn = numberColumn;
	}

	public Integer getNumberColumn() {
		return numberColumn;
	}

	public void addGenericCsvEntry(GenericCsvEntries entry){
		if(genericCsvEntries==null){
			genericCsvEntries=entry;
		}else{
			genericCsvEntries.merge(entry);
		}
	}
	
	public GenericCsvEntries getGenericCsvEntries(){
		return genericCsvEntries;
	}

	@Override
	public String toString() {
		return MoreObjects.toStringHelper(this).add("string", stringColumn).add("number", numberColumn).addValue(genericCsvEntries).toString();
	}
}
