package de.nittka.examples.csvbeanio;

import java.util.Map;
import java.util.Set;

import com.google.common.base.MoreObjects;
import com.google.common.base.MoreObjects.ToStringHelper;
import com.google.common.collect.Maps;

/**
 * data structure for holding key-value pairs, representing "unknown" columns of the csv file
 * */
public class GenericCsvEntries {

	private Map<String, String> entries = Maps.newHashMap();

	public GenericCsvEntries(String key, String value) {
		entries.put(key, value);
	}

	public String get(String key) {
		return entries.get(key);
	}

	public void merge(GenericCsvEntries entry) {
		Set<String> otherKeys = entry.entries.keySet();
		for (String key : otherKeys) {
			entries.put(key, entry.entries.get(key));
		}
	}

	@Override
	public String toString() {
		ToStringHelper builder = MoreObjects.toStringHelper("GenericCsvEntries");
		for (String key : entries.keySet()) {
			builder.add(key, entries.get(key));
		}
		builder.omitNullValues();
		return builder.toString();
	}
}
