package org.xtext.example.mydsl.ui;

import static com.google.common.collect.Sets.newHashSet;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.SubMonitor;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.jface.text.ITextSelection;
import org.eclipse.jface.text.Position;
import org.eclipse.jface.text.source.Annotation;
import org.eclipse.jface.text.source.IAnnotationModel;
import org.eclipse.jface.text.source.IAnnotationModelExtension;
import org.eclipse.jface.viewers.IPostSelectionProvider;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.swt.widgets.Display;
import org.eclipse.xtext.nodemodel.ICompositeNode;
import org.eclipse.xtext.nodemodel.ILeafNode;
import org.eclipse.xtext.nodemodel.util.NodeModelUtils;
import org.eclipse.xtext.resource.XtextResource;
import org.eclipse.xtext.ui.editor.IXtextEditorCallback;
import org.eclipse.xtext.ui.editor.XtextEditor;
import org.eclipse.xtext.ui.editor.model.IXtextDocument;
import org.eclipse.xtext.util.concurrent.IUnitOfWork;
import org.xtext.example.mydsl.myDsl.Greeting;
import org.xtext.example.mydsl.services.MyDslGrammarAccess;

import com.google.inject.Inject;

public class GreetingsMatchingTagMarker extends IXtextEditorCallback.NullImpl  implements ISelectionChangedListener {

	public static final String TAG_MARKER_TYPE="org.xtext.example.mydsl.ui.tagmarker";
	@Inject
	private TagMarkJob tagMarkJob;
	private XtextEditor editor;

	//register the selection change listener responsible for marking matching tags
	@Override
	public void afterCreatePartControl(XtextEditor editor) {
		this.editor=editor;
		ISelectionProvider provider = editor.getSelectionProvider();
		if(provider==null){
			return;
		}
		if(provider instanceof IPostSelectionProvider){
			((IPostSelectionProvider)provider).addPostSelectionChangedListener(this);
		} else{
			provider.addSelectionChangedListener(this);
		}
	}

	//unregister the selection change listener
	@Override
	public void beforeDispose(XtextEditor editor) {
		this.editor=null;
		ISelectionProvider provider = editor.getSelectionProvider();
		if(provider==null){
			return;
		}
		if(provider instanceof IPostSelectionProvider){
			((IPostSelectionProvider)provider).removePostSelectionChangedListener(this);
		} else{
			provider.removeSelectionChangedListener(this);
		}
	}

	//trigger a new job for marking matching tags on a selection change
	@Override
	public void selectionChanged(SelectionChangedEvent event) {
		if(event.getSelection() instanceof ITextSelection){
			tagMarkJob.cancel();
			tagMarkJob.initialize(editor, (ITextSelection) event.getSelection());
			if (!tagMarkJob.isSystem())
				tagMarkJob.setSystem(true);
			tagMarkJob.setPriority(Job.DECORATE);
			tagMarkJob.schedule();
		}
	}

	
	public static class TagMarkJob extends Job {
		@Inject
		private MyDslGrammarAccess grammarAccess;
		private IAnnotationModel annotationModel;
		private ITextSelection selection;
		private IXtextDocument document;

		public TagMarkJob() {
			super("markMatchingTags");
		}

		public void initialize(XtextEditor editor,
				ITextSelection selection) {
			annotationModel=editor.getInternalSourceViewer().getAnnotationModel();
			document=editor.getDocument();
			this.selection=selection;
		}

		@Override
		protected IStatus run(IProgressMonitor monitor) {
			final SubMonitor progress = SubMonitor.convert(monitor, 2);
			if (!progress.isCanceled()) {
				//retrieve new annotations
				final Map<Annotation, Position> annotations = createAnnotationMap(document, selection, progress.newChild(1));
				if (!progress.isCanceled()) {
					Display.getDefault().asyncExec(new Runnable() {
						public void run() {
							if (!progress.isCanceled()) {
								final IAnnotationModel model = annotationModel;
								if (model instanceof IAnnotationModelExtension)
									//replace existing annotations with new ones
									((IAnnotationModelExtension) model).replaceAnnotations(
											getExistingOccurrenceAnnotations(model), annotations);
								else if(model != null)
									throw new IllegalStateException(
											"AnnotationModel does not implement IAnnotationModelExtension");  //$NON-NLS-1$
							}
						}
					});
				}
			}
			return progress.isCanceled() ? Status.CANCEL_STATUS : Status.OK_STATUS;
		}

		@SuppressWarnings("unchecked")
		private Annotation[] getExistingOccurrenceAnnotations(IAnnotationModel annotationModel) {
			Set<Annotation> removeSet = newHashSet();
			//retrieve all annotations with "matching tag" type
			for (Iterator<Annotation> annotationIter = annotationModel.getAnnotationIterator(); annotationIter
					.hasNext();) {
				Annotation annotation = annotationIter.next();
				if (TAG_MARKER_TYPE.equals(annotation.getType())) {
					removeSet.add(annotation);
				}
			}
			return removeSet.toArray(new Annotation[0]);
		}

		//create a map with annotations for the new text selection 
		private Map<Annotation, Position> createAnnotationMap(final IXtextDocument document, final ITextSelection selection,
				final SubMonitor monitor) {
			if(document != null) {
				return document.readOnly(new IUnitOfWork<Map<Annotation, Position>, XtextResource>() {
					public Map<Annotation, Position> exec(final XtextResource resource) throws Exception {
						if(resource != null) {
							Map<Annotation, Position>result=new LinkedHashMap<Annotation, Position>();
							monitor.setWorkRemaining(2);
							//retrieve the selected model element 
							ILeafNode leaf = NodeModelUtils.findLeafNodeAtOffset(resource.getParseResult().getRootNode(), selection.getOffset());
							EObject semantic = NodeModelUtils.findActualSemanticObjectFor(leaf);
							monitor.worked(1);
							if (monitor.isCanceled()){
								return Collections.emptyMap();
							}
							//fill the map with annotations for that element
							fillAnnotationMap(semantic, selection.getOffset(), result);
							monitor.worked(1);
							return result;
							}
						return Collections.emptyMap();
					}
				});
			} else {
				return Collections.emptyMap();
			}
		}

		private void fillAnnotationMap(EObject object, int offset, Map<Annotation, Position> mapToFill){
			if(object instanceof Greeting){
				ICompositeNode complete = NodeModelUtils.getNode(object);
				//check if the selection really points to the given object
				//may not be the case as the current position may be in a hidden token before the actual model element begins
				//or after the last one ended
				if(complete.getOffset()<=offset && offset<=complete.getOffset()+complete.getLength()){
					//in this simple example we only need to iterate over the leaf nodes
					//extracting the "Hello"- and "!"-keyword positions
					for (ILeafNode leaf : complete.getLeafNodes()) {
						EObject grammarElement = leaf.getGrammarElement();
						if(grammarAccess.getGreetingAccess().getHelloKeyword_0().equals(grammarElement)){
							Annotation annotation=new Annotation(TAG_MARKER_TYPE, false,"");
							mapToFill.put(annotation, new Position(leaf.getOffset(), leaf.getLength()));
						}else if(grammarAccess.getGreetingAccess().getExclamationMarkKeyword_2().equals(grammarElement)){
							Annotation annotation=new Annotation(TAG_MARKER_TYPE, false,"");
							mapToFill.put(annotation, new Position(leaf.getOffset(), leaf.getLength()));
						}
					}
				}
			}
		}
	}
}
